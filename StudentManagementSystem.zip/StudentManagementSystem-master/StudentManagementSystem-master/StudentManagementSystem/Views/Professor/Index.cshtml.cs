using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace StudentManagementSystem.Views.Professor
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
